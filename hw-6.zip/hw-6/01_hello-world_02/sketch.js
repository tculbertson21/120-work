function setup(){
    ellipse(20, 20, 30, 30);
}
